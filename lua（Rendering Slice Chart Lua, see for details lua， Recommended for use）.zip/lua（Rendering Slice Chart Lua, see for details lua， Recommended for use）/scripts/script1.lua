function onUpdate()
    if curStep == 21474836478888888 then
    setProperty("opCombo", 9178)
    setProperty("combo", 114514)
    setProperty("totalNpsMax", 7891)
    setProperty("bfNpsMax", 91787)
    setProperty("opNpsMax", 666)
    end
    if curStep == 24 then
    setProperty("opCombo", 0)--Set up opponent notes before
    setProperty("combo", 0)--Before setting up BF notes
    setProperty("totalNpsMax", 18615)
    setProperty("bfNpsMax", 846119)
    setProperty("opNpsMax", 917864)
    end
end